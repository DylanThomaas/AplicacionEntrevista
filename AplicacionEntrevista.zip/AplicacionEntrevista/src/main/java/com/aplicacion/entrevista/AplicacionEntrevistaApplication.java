package com.aplicacion.entrevista;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AplicacionEntrevistaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AplicacionEntrevistaApplication.class, args);
	}

}
